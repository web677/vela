<!--
 * @Date: 2024-03-06 17:45:26
 * @LastEditors: yawen Yang
 * @LastEditTime: 2024-04-24 10:15:18
 * @FilePath: /gt4-public-client-demo/README.md
-->
# captcha demo

## Project setup
```
npm run/yarn install
```

### Compiles and hot-reloads for development
```
npm run/yarn serve
```

### Compiles and minifies for production
```
npm run/yarn build
```

### 1、find index.html in your project
### 2、add  <script src="xxx/ct4.js"></script> in index.html 
### 3、declare Window in global
### 4、init Captcha like demo above

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
