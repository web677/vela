<!--
 * @Date: 2024-04-24 11:03:07
 * @LastEditors: yawen Yang
 * @LastEditTime: 2024-04-24 11:12:05
 * @FilePath: /gt4-public-client-demo/README.md
-->
# captcha demo

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.0.1.
## Project setup
```
yarn/npm install
```

## Compiles and hot-reloads for development
```
yarn/npm start
```

## Compiles and minifies for production
```
yarn/npm build
```

### 1、find index.html in your project
### 2、add  <script src="xxx/ct4.js"></script> in index.html 
### 3、init Captcha like demo above


## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.
