/*
 * @Date: 2024-04-24 11:03:07
 * @LastEditors: yawen Yang
 * @LastEditTime: 2024-04-24 11:12:33
 * @FilePath: /gt4-public-client-demo/src/app/captcha/captcha.component.ts
 */
import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-captcha',
  templateUrl: './captcha.component.html',
  styleUrls: ['./captcha.component.scss']
})
export class CaptchaComponent implements OnInit {
  @Input() captchaConfig:any
  constructor() { }

  ngOnInit(): void {
    (window as any).initAlicom4(
      this.captchaConfig.config,
      this.captchaConfig.handler
    );
  }
}
