/*
 * @Author: yangyawen 786878243@qq.com
 * @Date: 2023-10-11 10:58:32
 * @LastEditors: yawen Yang
 * @LastEditTime: 2024-04-24 11:46:29
 * @FilePath: /gt4-public-client-demo/web/js/captcha.js
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
 */
var showCaptcha = function(){}
var resetCaptcha = function(){}
var destroyCaptcha = function(){}

function initCaptcha(){
  initAlicom4({
    captchaId: "8848b0418f53cc0c2cc6853c6d20c6d3",
    product: 'bind',
    language: 'eng'
},function (captcha) {
  showCaptcha = function(){
    captcha.showCaptcha();
  }
  resetCaptcha = function(){
    captcha.reset()
  }
  destroyCaptcha = function(){
    captcha.destroy()
  }
  // captcha为验证码实例
  captcha
    .onReady(function(){
    })
    .onNextReady(function(){
    })
    .onSuccess(function(){
      var result = captcha.getValidate();
      getSuccess(result.captcha_id,result.lot_number,result.pass_token,result.captcha_output);
    })
    .onFail(function(failObj){
      getFail(failObj.captchaId,failObj.captchaType,failObj.lotNumber)
    })
    .onError(function(error){
      console.log(error)
    })
  })
};
