# captcha demo

## Project setup
```
flutter run -d chrome
```

### 1、find index.html in your project(path:web)
### 2、add  <script src="xxx/ct4.js"></script> in index.html 
### 3、provide your captchaID in captcha.js (path: web/js)
### 4、init Captcha like demo above

### Customize configuration
See [online documentation](https://docs.flutter.dev/).
