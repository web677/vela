# React Native webview captcha demo
```
Node above v18
```
## Project setup
```
yarn/npm install
```

### Compiles and hot-reloads for development
```
yarn/npm run   ios/android
```

### Start Metro service
```
yarn/npm run   start
```

### 1、Find webview page demo.html in assets
### 2、Deploy the intermediate page to your server
### 3、Modify the source address in pages/webview.tsx to the intermediate page address you published 
### 4、init Captcha like demo above

