/*
 * @Date: 2024-04-24 11:20:01
 * @LastEditors: yawen Yang
 * @LastEditTime: 2024-04-24 11:30:18
 * @FilePath: /gt4-public-client-demo/src/App.test.tsx
 */
import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  // expect(linkElement).toBeInTheDocument();
});
