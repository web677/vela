/*
 * @Description: 本地二次校验
 * @Version: 1.0.0
 * @Date: 2022-04-11 18:01:54
 * @LastEditors: yawen Yang
 * @LastEditTime: 2024-04-24 11:32:49
 */
const koa = require("koa");
const Router = require("@koa/router");
const axios = require("axios");
const crypto = require("crypto");
const koaStatic = require("koa-static");

const app = new koa();
const router = new Router();
app.use(koaStatic(__dirname + "/build"));

app.use(async (ctx, next) => {
  ctx.set("Access-Control-Allow-Origin", "*");
  ctx.set(
    "Access-Control-Allow-Headers",
    "Content-Type, Content-Length, Authorization, Accept, X-Requested-With"
  );
  ctx.set("Access-Control-Allow-Methods", "PUT, POST, GET, DELETE, OPTIONS");
  if (ctx.method == "OPTIONS") {
    ctx.body = 200;
  } else {
    await next();
  }
});

app.use(router.routes()).listen(3001, () => {
  console.log("server is running in 3001");
});